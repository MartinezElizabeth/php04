Tema4.1
<?php
$dia = 24; //se declara una variable de tipo integer.
$sueldo = 758.43;//se declara una variable  de tipo double.
$nombre = "UTIC";//se declara una variable de tipo String
$exite = true;//se declara una variable de tipo boolean.
echo "Valraible entera:";
echo $dia;
echo PHP_EOL;;
echo"Variable double:";
echo $sueldo;
echo PHP_EOL;
echo "Variable string:";
echo $nombre;
echo PHP_EOL;
echo "Variable boolean:";
echo $exite;
?>