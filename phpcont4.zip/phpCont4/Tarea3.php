<?php
$cadena1 = "diego";
$cadena2 = "juan";
$cadena3 = "ana";
$todo = $cadena1.", ".$cadena2.", " . $cadena3.PHP_EOL;
echo $todo;
$edad1 = 24 ;
echo $cadena1 . "tiene $edad1 de edad " . PHP_EOL;
?>